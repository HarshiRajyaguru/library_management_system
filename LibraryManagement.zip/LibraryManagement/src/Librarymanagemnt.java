/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projects;

/**
 *
 * @author SNEHA
 */
import java.sql.*;
import javax.sql.*;
import java.util.*;
public class Librarymanagemnt {
    static{
        System.out.println("LIBRARAY MANAGEMENT PROJECT");
    }
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
  Class.forName("com.mysql.cj.jdbc.Driver");
System.out.println("driver loded succesfully");

String url = "jdbc:mysql://localhost:3306/recall";
String username = "root"; // XAMPP default username
String password = "";     // XAMPP default password (empty)

Connection con = DriverManager.getConnection(url, username, password);
System.out.println("connected successfully with the database");

        
        Scanner sc=new Scanner(System.in);
        System.out.println("=======LIBRARY_MANAGEMENT======");
        System.out.println("1.AddBooks");
        System.out.println("2.ViewBooks");
        System.out.println("3.id reference books");
        System.out.println("4.AddStudent");
        System.out.println("5.viewstudents");
        System.out.println("6.id reference student");
        System.out.println("7..BookIssue");
        System.out.println("8.ViewIssuedBooks");
        System.out.println("9.id referance issuedbooks");
        System.out.println("10.ExIT");
        System.out.println("======choose one in this======");
        int choice=sc.nextInt();
        
        switch(choice){
            case 1:
                System.out.println("enter book_id");
                int a=sc.nextInt();
                System.out.println("enter author");
                sc.nextLine();
                String c=sc.nextLine();
                System.out.println("enter title");
                String cc=sc.nextLine();
                System.out.println("enter quantity");
                int v=sc.nextInt();
                sc.nextLine();
                String s="insert into book values(?,?,?,?)";
                PreparedStatement pst=con.prepareStatement(s);
                      
                con.setAutoCommit(false);
                
                pst.setInt(1,a);
                pst.setString(2,c);
                pst.setString(3, cc);
                pst.setInt(4,v);
                int i=   pst.executeUpdate();
                con.commit();
             
         
           
             pst.close();
                break;
     
      
               
               case 2:
                System.out.println("Retriving the values ");
                String r="select*from book";
                PreparedStatement aa=con.prepareStatement(r);
                ResultSet rs=  aa.executeQuery();
                while(rs.next()){
                System.out.println("id=>"+rs.getInt(1)+" |author==>"+rs.getString(2)+" |title=>"+rs.getString(3)+" |quantity=>" +rs.getInt(4));
            }
                aa.close();
                rs.close();
                break;
                
              case 3:
                  System.out.println("===id referancebooks");
                  System.out.println("enter id");
                  int vv=sc.nextInt();
                    String bbb="select*from book where book_id=?";
                    PreparedStatement st=con.prepareStatement(bbb);
                    st.setInt(1,vv);
                  ResultSet f=  st.executeQuery();
                 if(f.next()){
                     System.out.println(" |id is :" +f.getInt(1)+" |author is :"+f.getString(2)+" |title is :" +f.getInt(3)+" |quantiy is :" +f.getInt(4) );
                 }
                 else{
                     System.out.println("there is rows inside the table ");
                 }
                 st.close();
                 f.close();
                 break;
                case 4:
                   
                    System.out.println("enter name ");
                    String n=sc.nextLine();
                    sc.nextLine();
                    System.out.println("enter id ");
                    int b=sc.nextInt();
                    sc.nextLine();
                    System.out.println("enter course");
                    String sn=sc.nextLine();
                   
                    
                    ///query write here
                   String bb="insert into student values(?,?,?)";
                    PreparedStatement aaa=con.prepareStatement(bb);
                    con.setAutoCommit(false);
                    aaa.setString(1,n);
                    aaa.setInt(2, b);
                    aaa.setString(3, sn);
          
                    aaa.executeUpdate();
                     con.commit();
                    System.out.println("if you want to insert more rows(yes/no)");
                    String m=sc.nextLine();
                    if(m.equalsIgnoreCase("no")){
                    System.out.println("STOP ISERTING THE VALUES");
                     break;
                  }
     
                   break;
                   
                case 5:
                   String bc="select*from student";
             PreparedStatement caa=con.prepareStatement(bc);
       ResultSet rss=caa.executeQuery();

     boolean found = false;
     while(rss.next()){
    found = true;
    System.out.println(" ->>>|name is :" +rss.getString(1)+" ->>>|id is :" +rss.getInt(2)+" ->>>|course is :" +rss.getString(3));
   }
   if(!found){
    System.out.println("there will be no rows in the table ");
   }
   caa.close();
   rss.close();

                break;
                
                case 6:
                    System.out.println("enter student id");
                    int d=sc.nextInt();
                    String dd="select*from student where id=?";
                    PreparedStatement ava=con.prepareStatement(dd);
                    ava.setInt(1, d);
                    ResultSet mm= ava.executeQuery();
                    if(mm.next()){
                        System.out.println(" ->>>> |name is :" +mm.getString(1)+" ->>>> |id is :" +mm.getInt(2)+" ->>>>course is :" +mm.getString(3));
                    }
                    else
                    {
                        System.out.println("there is no row iside the table");
                    }
                    ava.close();
                    mm.close();
                break;
                
                case 7:
                    System.out.println("enter issue id");
                    int issue_id=sc.nextInt();
                    sc.nextLine();
                    System.out.println("enter book id ");
                    int book_id=sc.nextInt();
                    sc.nextLine();
                    System.out.println("enter id");
                    int iid=sc.nextInt();
                    sc.nextLine();
                    System.out.println("enter issue_date");
                    String issue_date=sc.nextLine();
                    System.out.println("enter return date");
                    String Return_date=sc.nextLine();
                    
                    String ccc="insert into book_issue values(?,?,?,?,?)";
                    PreparedStatement mn=con.prepareStatement(ccc);
                    con.setAutoCommit(false);
                    mn.setInt(1,issue_id);
                    mn.setInt(2,book_id);
                    mn.setInt(3, iid);
                    mn.setString(4,issue_date);
                    mn.setString(5,Return_date);
                  int ii=  mn.executeUpdate();
                  if(ii>0){
                      System.out.println("row is effected in your table ");
                  }
                  else
                  {
                      System.out.println("row is not effected in your table");
                  }
               
                    con.rollback();
                  
                    
                    System.out.println("if you want to insert more rows(yes/no)");
                    String k=sc.nextLine();
                     if(k.equalsIgnoreCase("no")){
                    System.out.println("STOP ISERTING THE VALUES");
                     break;
             
                   }
                   mn.close();
                   break;
                   
                case 8:
                    System.out.println("retriving the date over here");
                    String j="select*from book_issue ";
                     PreparedStatement nn=con.prepareStatement(j);
                     ResultSet ff=nn.executeQuery();
                      if(ff.next()){
                          System.out.println("issue_is is :" +ff.getInt(1)+"book_id is :" +ff.getInt(2)+"student_id is :" +ff.getInt(3)+"issue_date is :" +ff.getString(4)+"return_date is :" +ff.getString(5));
                      }
                   else
                      {
                          System.out.println("there will be no row inyour table ");
                      }
                      nn.close();
                      ff.close();
                      break;
                      
                case 9:
                    System.out.println("using id we can see issued  books ");
                    
                    System.out.println("enter issue_id");
                    int issue_iid=sc.nextInt();
                    String l="select *from book_issue where issue_id=?";
                    PreparedStatement nnn=con.prepareStatement(l);
                    nnn.setInt(1,issue_iid);
                    
                    ResultSet fff=nnn.executeQuery();
                      if(fff.next()){
                          System.out.println("issue_is is :" +fff.getInt(1)+"book_id is :" +fff.getInt(2)+"student_id is :" +fff.getInt(3)+"issue_date is :" +fff.getString(4)+"return_date is :" +fff.getString(5));
                      }
                   else
                      {
                          System.out.println("there will be no row in your table ");
                      }
                      fff.close();
                      nnn.close();
                      break;
                      
                case 10:
                    System.out.println("exit the project");
                    break;
                    
                default :
                    System.out.println("THIS IS ALL ABOUT LIBRARY PROJECT ");
                    System.out.println("CHECK ONCE AND GIVE THE CORRECT CHOICE ");
                    
              }
   
    }

}
